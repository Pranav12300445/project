package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

    @Autowired
    private EmployeeService service;

    // CREATE Employee
    @PostMapping("/create")
    public Employee createEmployee(@RequestBody Employee emp) {
        return service.create(emp);
    }

    // DISPLAY All Employees
    @GetMapping("/display")
    public List<Employee> displayEmployees() {
        return service.getAll();
    }

    // RAISE SALARY
    @PutMapping("/raiseSalary")
    public String raiseSalary() {
        return service.raiseSalary();
    }
}