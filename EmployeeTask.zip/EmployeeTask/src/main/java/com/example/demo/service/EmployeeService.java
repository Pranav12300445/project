package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepo;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo repo;

    public Employee create(Employee emp) {

        if(emp.getDesignation().equalsIgnoreCase("Programmer"))
            emp.setSalary(25000);
        else if(emp.getDesignation().equalsIgnoreCase("Manager"))
            emp.setSalary(30000);
        else if(emp.getDesignation().equalsIgnoreCase("Tester"))
            emp.setSalary(20000);

        return repo.save(emp);
    }

    public List<Employee> getAll() {
        return repo.findAll();
    }

    public String raiseSalary() {

        List<Employee> employees = repo.findAll();

        for(Employee e : employees) {

            if(e.getDesignation().equalsIgnoreCase("Programmer"))
                e.setSalary(e.getSalary() + 5000);
            else if(e.getDesignation().equalsIgnoreCase("Manager"))
                e.setSalary(e.getSalary() + 7000);
            else if(e.getDesignation().equalsIgnoreCase("Tester"))
                e.setSalary(e.getSalary() + 4000);

            repo.save(e);
        }

        return "Salary Updated";
    }
}